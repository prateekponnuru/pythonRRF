from django.contrib import admin
from .models import document
# Register your models here.

